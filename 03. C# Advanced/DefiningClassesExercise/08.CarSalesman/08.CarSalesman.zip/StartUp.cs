﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int quantityEngines = int.Parse(Console.ReadLine());
            List<Car> allCars = new List<Car>();
            List<Engine> engines = new List<Engine>();
            for (int i = 0; i < quantityEngines; i++)
            {
                string[] engineInfo = Console.ReadLine()
                    .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                string model = engineInfo[0];
                int power = int.Parse(engineInfo[1]);
                int displacement;
                string efficiency = null;
                if (engineInfo.Length == 2)
                {
                    Engine engine = new Engine(model, power);
                    engines.Add(engine);
                }

                else if (engineInfo.Length == 4)
                {
                    displacement = int.Parse(engineInfo[2]);
                    efficiency = engineInfo[3];
                    Engine engine = new Engine(model, power, displacement, efficiency);
                    engines.Add(engine);
                }
                else if (engineInfo.Length == 3)
                {
                    bool isInt = int.TryParse(engineInfo[2], out displacement);
                    if (!isInt)
                    {
                        efficiency = engineInfo[2];
                        Engine engine = new Engine(model, power, efficiency);
                        engines.Add(engine);
                    }
                    else
                    {
                        Engine engine = new Engine(model, power, displacement);
                        engines.Add(engine);
                    }
                }
                //Engine engine = new Engine(model, power, displacement, efficiency);
            }
            int quantityCars = int.Parse(Console.ReadLine());
            for (int i = 0; i < quantityCars; i++)
            {
                string[] carInfo = Console.ReadLine()
                    .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                string model = carInfo[0];
                string engineModel = carInfo[1];
                Engine engine = engines.First(e => e.Model == engineModel);
                //engines.Contains(engineModel).
                int weight;
                string color = null;
                if (carInfo.Length == 2)
                {
                    Car car = new Car(model, engine);
                    allCars.Add(car);
                }
                else if (carInfo.Length == 3)
                {
                    bool isInt = int.TryParse(carInfo[2], out weight);
                    if (!isInt)
                    {
                        color = carInfo[2];
                        Car car = new Car(model, engine, color);
                        allCars.Add(car);
                    }
                    else
                    {
                        Car car = new Car(model, engine, weight);
                        allCars.Add(car);
                    }
                }
                else
                {
                    weight = int.Parse(carInfo[2]);
                    color = carInfo[3];
                    Car car = new Car(model, engine, weight, color);
                    allCars.Add(car);
                }
                //"{model} {engine} {weight} {color}"
            }
            Console.WriteLine(string.Join("",allCars));
        }
    }
}
